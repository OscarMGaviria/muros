from fastapi import APIRouter, HTTPException
import uuid
from wall_engine.api.schemas.wall_schema import WallDesignRequest
from wall_engine.units.registry import Q_
from wall_engine.domain.wall.geometry import WallGeometry
from wall_engine.domain.materials.entities import WallMaterials, Concrete, ReinforcementSteel
from wall_engine.domain.soil.entities import Soil
from wall_engine.seismic.parameters import SeismicParameters
from wall_engine.domain.wall.entities import Wall
from wall_engine.codes.ccp14.orchestrator import CCP14Orchestrator

# Temporarily patch domain entities loads if TrafficSurcharge is not there
# Assume it might fail if we don't handle traffic properly, we'll map it to None for now if not implemented.

router = APIRouter()

@router.post("/ccp14")
def design_wall_ccp14(request: WallDesignRequest):
    try:
        # 1. Map Schema to Domain
        geom = WallGeometry(
            stem_height=Q_(request.geometry.stem_height_m, "m"),
            stem_thickness_base=Q_(request.geometry.stem_thickness_base_m, "m"),
            stem_thickness_top=Q_(request.geometry.stem_thickness_top_m, "m"),
            footing_width=Q_(request.geometry.footing_width_m, "m"),
            footing_thickness=Q_(request.geometry.footing_thickness_m, "m"),
            toe_length=Q_(request.geometry.toe_length_m, "m"),
            heel_length=Q_(request.geometry.heel_length_m, "m"),
            toe_cover_soil=Q_(request.geometry.toe_cover_soil_m, "m"),
            key_depth=Q_(request.geometry.key_depth_m, "m") if request.geometry.key_depth_m else None,
            key_width=Q_(request.geometry.key_width_m, "m") if request.geometry.key_width_m else None,
            backfill_slope=Q_(request.geometry.backfill_slope_deg, "degrees"),
            stem_batter=Q_(request.geometry.stem_batter_deg, "degrees"),
            back_face_angle=Q_(request.geometry.back_face_angle_deg, "degrees")
        )
        
        mats = WallMaterials(
            concrete=Concrete(fc=Q_(request.materials.concrete.fc_MPa, "MPa"), gamma=Q_(request.materials.concrete.gamma_kN_m3, "kN/m**3"), elasticity=None),
            reinforcement=ReinforcementSteel(fy=Q_(request.materials.reinforcement.fy_MPa, "MPa"), fsu=None, elasticity=Q_(request.materials.reinforcement.Es_MPa, "MPa")),
            cover=Q_(request.materials.cover_cm, "cm")
        )
        
        back_soil = Soil(
            name=request.backfill.name,
            unit_weight=Q_(request.backfill.gamma_kN_m3, "kN/m**3"),
            saturated_unit_weight=None,
            friction_angle=Q_(request.backfill.phi_deg, "degrees"),
            cohesion=Q_(request.backfill.cohesion_kPa, "kPa"),
            interface_friction_angle=Q_(request.backfill.interface_friction_deg, "degrees") if request.backfill.interface_friction_deg is not None else Q_(request.backfill.phi_deg * 0.66, "degrees"),
            bearing_capacity=None
        )
        
        found_soil = Soil(
            name=request.foundation_soil.name,
            unit_weight=Q_(request.foundation_soil.gamma_kN_m3, "kN/m**3"),
            saturated_unit_weight=None,
            friction_angle=Q_(request.foundation_soil.phi_deg, "degrees"),
            cohesion=Q_(request.foundation_soil.cohesion_kPa, "kPa"),
            interface_friction_angle=Q_(request.foundation_soil.interface_friction_deg, "degrees") if request.foundation_soil.interface_friction_deg is not None else Q_(request.foundation_soil.phi_deg, "degrees"),
            bearing_capacity=Q_(request.foundation_soil.bearing_capacity_kPa, "kPa") if request.foundation_soil.bearing_capacity_kPa else None
        )
        
        seis = SeismicParameters(
            ag=request.seismic.kh if request.seismic else 0.0,
            kh=request.seismic.kh if request.seismic else 0.0,
            kv=request.seismic.kv if request.seismic else 0.0,
            soil_factor=None, seismic_zone=None
        )
        
        wall = Wall(
            id=uuid.uuid4(),
            name=request.name,
            geometry=geom,
            materials=mats,
            backfill=back_soil,
            foundation_soil=found_soil,
            groundwater=None,
            surcharges=[],
            seismic=seis
        )
        
        # 2. Run Engine
        orch = CCP14Orchestrator()
        report = orch.design_wall(wall)
        
        # 3. Return a clean dict (Pydantic models will be implemented later, for now we return raw dict)
        # To avoid Pint Quantity serialization errors, we extract magnitudes manually for the critical results.
        
        res = {
            "wall_name": report.wall_name,
            "status": report.status,
            "stability": {},
            "reinforcement": {
                "stem_base_As_cm2_m": report.structural_design.stem_base.As_required.to("cm**2/m").magnitude,
                "toe_As_cm2_m": report.structural_design.toe.As_required.to("cm**2/m").magnitude,
                "heel_As_cm2_m": report.structural_design.heel.As_required.to("cm**2/m").magnitude
            }
        }
        
        for ls, stab in report.stability_results.items():
            res["stability"][ls] = {
                "FS_sliding": float(stab.FS_sliding),
                "FS_overturning": float(stab.FS_overturning),
                "eccentricity_m": stab.eccentricity.to("m").magnitude,
                "safe_eccentricity": stab.is_safe_eccentricity
            }
            
        return res
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
